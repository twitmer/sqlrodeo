package com.tom.dbslurper

import com.tom.dbslurper.actions.IDelegate
import com.tom.dbslurper.context.DbSlurperContext


class DoNothingDelegate implements IDelegate {

    public DoNothingDelegate() {
        println "Created DoNothingDelegate"
    }

    @Override
    public void execute(DbSlurperContext context, String text) {
        println "Running test delegate with text=$text"
//        throw new RuntimeException("Testing out the line number reporting!")
    }
}
