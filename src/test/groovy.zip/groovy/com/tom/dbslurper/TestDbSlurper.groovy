package com.tom.dbslurper

import static org.junit.Assert.assertEquals
import static org.junit.Assert.assertNotEquals
import spock.lang.Ignore
import spock.lang.Specification

class TestDbSlurper extends spock.lang.Specification {

    @Ignore
    def "do something"(){

        given: "My XML"
        URL resourceUrl = this.getClass().getResource( '/master-script.xml' )
        println "resourceUrl=$resourceUrl"
        DbSlurper slurper = new DbSlurper()
        try{
            slurper.execute(resourceUrl)
        }
        catch(Exception ex){
            throw ex;
        }

        expect:
        1 == 1
    }
}
