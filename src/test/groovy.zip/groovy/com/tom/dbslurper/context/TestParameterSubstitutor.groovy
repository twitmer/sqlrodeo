package com.tom.dbslurper.context;

import java.util.regex.Matcher

import spock.lang.Specification

public class TestParameterSubstitutor extends Specification {

    def "test parameters"(){

        expect:
        // Invalid identifiers
        !SubstitutionService.varPattern.matcher('').matches()
        !SubstitutionService.varPattern.matcher('$').matches()
        !SubstitutionService.varPattern.matcher('${').matches()
        !SubstitutionService.varPattern.matcher('${}').matches()
//        !ParameterSubstitutor.varPattern.matcher('${12}').matches()
//        !ParameterSubstitutor.varPattern.matcher('${a-a}').matches()
//        !ParameterSubstitutor.varPattern.matcher('${a@a}').matches()
//        !ParameterSubstitutor.varPattern.matcher('${a&a}').matches()
//        !ParameterSubstitutor.varPattern.matcher('${a"a}').matches()
//        !ParameterSubstitutor.varPattern.matcher('${a[a}').matches()
//        !ParameterSubstitutor.varPattern.matcher('${a]a}').matches()

        // Valid identifiers
        SubstitutionService.varPattern.matcher('${a}').matches()
        SubstitutionService.varPattern.matcher('${aa}').matches()
        SubstitutionService.varPattern.matcher('${a1}').matches()
        SubstitutionService.varPattern.matcher('${aa1}').matches()
        SubstitutionService.varPattern.matcher('${a1a}').matches()
        SubstitutionService.varPattern.matcher('${a_a}').matches()

        // Typical identifiers
        SubstitutionService.varPattern.matcher('${somethi3ng}').matches()
        SubstitutionService.varPattern.matcher('${release}').matches()
        SubstitutionService.varPattern.matcher('${build}').matches()
        SubstitutionService.varPattern.matcher('${version}').matches()

        when: "Target string is in double quotes"
        // WARNING: Use single quotes here to prevent groovy from doing substitution!
        SubstitutionService.varPattern.matcher("${somethi3ng}").matches()

        then: "Groovy throws exception because it tried to do variable substitution"
        thrown(MissingPropertyException)

        when: "An expression with things to substitute"
        String value= 'Some string with ${count} variables'
        Matcher matcher = SubstitutionService.varPattern.matcher(value)
        while( matcher.find() ){
            println "Found: " + matcher.group(0) + " in $value"
            String term = matcher.group(0)
            term = term.substring(2, term.length() - 1);
            println "Shrank to $term"
        }

        value= 'Another ${expletive} string with ${count} ${count}  ${freaking} variables'
        String
        matcher = SubstitutionService.varPattern.matcher(value)
        while( matcher.find() ){
            println "Found: " + matcher.group(0) + " in $value"
        }

        then:
        1==1
    }

    def "test for real"(){
        
        given:
        def source = 'Another ${expletive} ${sysProps.get(\"os.arch\")} string with ${count} ${count} ${freaking} variables'
        DbSlurperContext context = new DbSlurperContext()
        context.put("count", "3")
        context.put("expletive", Long.valueOf(5))
        context.put("freaking", ["gosh","darned","diddly","darned"])
        
        System.properties.get("")
        def result = SubstitutionService.substitute(source, context)
        
        println "result is now $result"
    }

}

