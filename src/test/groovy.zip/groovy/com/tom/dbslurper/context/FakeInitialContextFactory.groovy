package com.tom.dbslurper.context

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.spi.InitialContextFactory;
import javax.naming.spi.NamingManager;
import javax.naming.spi.ObjectFactory;

class FakeInitialContextFactory implements InitialContextFactory {

    private Map context = new HashMap<Object,Object>();


    private final Hashtable<String,Object> boundObjects = new Hashtable<String,Object>();


    @Override
    public Context getInitialContext(Hashtable<?, ?> environment) throws NamingException {
        return new FakeContext(context,environment);
    }



    /**
     * Simple InitialContextFactoryBuilder implementation,
     * creating a new SimpleNamingContext instance.
     * @see SimpleNamingContext
     */
//    public InitialContextFactory createsInitialContextFactory(Hashtable<?,?> environment) {
//        if (activated == null && environment != null) {
//            Object icf = environment.get(DbSlurperContext.INITIAL_CONTEXT_FACTORY);
//            if (icf != null) {
//                Class<?> icfClass = null;
//                if (icf instanceof Class) {
//                    icfClass = (Class<?>) icf;
//                }
//                else if (icf instanceof String) {
//                    icfClass = ClassUtils.resolveClassName((String) icf, getClass().getClassLoader());
//                }
//                else {
//                    throw new IllegalArgumentException("Invalid value type for environment key [" +
//                            DbSlurperContext.INITIAL_CONTEXT_FACTORY + "]: " + icf.getClass().getName());
//                }
//                if (!InitialContextFactory.class.isAssignableFrom(icfClass)) {
//                    throw new IllegalArgumentException(
//                            "Specified class does not implement [" + InitialContextFactory.class.getName() + "]: " + icf);
//                }
//                try {
//                    return (InitialContextFactory) icfClass.newInstance();
//                }
//                catch (Throwable ex) {
//                    IllegalStateException ise =
//                            new IllegalStateException("Cannot instantiate specified InitialContextFactory: " + icf);
//                    ise.initCause(ex);
//                    throw ise;
//                }
//            }
//        }
//
//        // Default case...
//        return new InitialContextFactory() {
//            @SuppressWarnings("unchecked")
//            public DbSlurperContext getInitialContext(Hashtable<?,?> environment) {
//                return new SimpleNamingContext("", boundObjects, (Hashtable<String, Object>) environment);
//            }
//        };
//    }

}
