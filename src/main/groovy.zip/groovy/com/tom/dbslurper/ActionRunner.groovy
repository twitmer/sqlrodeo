package com.tom.dbslurper

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.tom.dbslurper.actions.ActionFactory
import com.tom.dbslurper.actions.IAction
import com.tom.dbslurper.context.DbSlurperContext
import com.tom.dbslurper.util.StringUtils


public class ActionRunner {
    Logger logger = LoggerFactory.getLogger(this.class);

    /**
     * 
     * @param node
     * @param context
     * @return True if child nodes should be executed, false if they should be skipped.
     */
    public boolean execute(Node node, DbSlurperContext context) {
        //        logger.debug "Executing node: $node"

        // Evaluate possible 'if' condition.
        if ( !ifConditionIsTrue(node, context)){
            logger.debug "if=[${node.attribute('if')}] failed, so not executing $node"
            return false
        }

        // Create action and invoke for this node.
        IAction action = new ActionFactory().build(node)
        logger.info "Executing action: ${action.getClass().getName()} from $node in ${action.resolveResourceUrl(node)}"
        try {
            action.execute(node, context)
        } catch (Exception e) {
            throw new RuntimeException("Error while executing <${node.name()}> element at: " + action.resolveResourceUrl(node) + " line " + node.attribute("_line") + ": " + e.getMessage(), e)
        }

        // Don't run children of Query or Sql nodes.
        if ( node.name().equals("query") || node.name().equals("sql") ){
            logger.debug "Skipping children of node: $node"
            return false
        }

        // Default fall-through: run the children.
        return true
    }

    boolean ifConditionIsTrue(Node node, DbSlurperContext context) {
        String condition = node.attribute("if")
        if ( StringUtils.isEmpty(condition)){
            return true;
        }

        // There's actually an if-condition. Process it now.
        return JexlService.evaluateBoolean(condition, context)
    }
}