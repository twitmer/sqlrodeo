package com.tom.dbslurper

import javax.xml.parsers.SAXParser

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.xml.sax.Attributes
import org.xml.sax.Locator
import org.xml.sax.SAXException
import org.xml.sax.XMLReader

import javax.xml.parsers.*;

class MyXmlParser extends XmlParser {

    public MyXmlParser() throws ParserConfigurationException, SAXException {
    }

    public MyXmlParser(XMLReader reader) {
        super(reader);
    }

    public MyXmlParser(SAXParser parser) throws SAXException {
        super(parser);
    }

    public MyXmlParser(boolean validating, boolean namespaceAware) throws ParserConfigurationException, SAXException {
        super(validating, namespaceAware);
    }

    public MyXmlParser(boolean validating, boolean namespaceAware, boolean allowDocTypeDeclaration)
    throws ParserConfigurationException, SAXException {
        super(validating, namespaceAware, allowDocTypeDeclaration);
    }

    @Override
    protected Node createNode(Node parent, Object name, Map attributes) {
        // Capture the line number for each element for future error reporting.
        Locator locator = this.getDocumentLocator()
        attributes.put("_line", locator.lineNumber)
        // attributes.put("_col",locator.columnNumber)
        return super.createNode(parent, name, attributes);
    }
}