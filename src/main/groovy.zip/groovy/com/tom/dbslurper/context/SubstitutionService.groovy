package com.tom.dbslurper.context

import java.util.regex.Matcher
import java.util.regex.Pattern

import org.apache.commons.jexl2.JexlContext
import org.apache.commons.jexl2.JexlEngine
import org.apache.commons.jexl2.MapContext
import org.slf4j.Logger;import org.slf4j.LoggerFactory
import org.slf4j.Logger;import org.slf4j.LoggerFactory

class SubstitutionService {
    
    private static final Logger logger = LoggerFactory.getLogger(this.class);

    /**
     * Variable is anything beginning with "${", ending with "}". Anything in between "{" and "}" is valid, except for another "{" or "}".
     */
    public static Pattern varPattern = ~/\$\{[^{}]+\}/

    /**
     * Private constructor to disable instantiation.
     */
    private SubstitutionService() {
    }

    public static String substitute(String source, DbSlurperContext context){

        JexlEngine jexl = new JexlEngine();
        JexlContext jc = new MapContext(context);

        String workingSource = source;
        Matcher matcher = SubstitutionService.varPattern.matcher(workingSource)
        while( matcher.find() ){
            String term = matcher.group(0)
            logger.debug "Found: " + term + " in $workingSource"

            // Remove the "${" and "}" parts of the match so we can evaluate it via JEXL.
            term = term.substring(2, term.length() - 1);

            // Evaluate the term inside the "${" and "}"
            Object o = jexl.createExpression( term ).evaluate(jc)

            logger.debug "evaluated [$term] to [$o]"
            // Now replace all instances of the variable with its evaluated equivalent.
            // Use 'replace' method to replace text, since it does not expand regexes.
            def newWorkingSource = workingSource.replace('${'+term+'}', o.toString())
            logger.debug "New workingSource = $workingSource"
            if ( newWorkingSource.equals(workingSource)){
                throw new RuntimeException("Failed to replace [$term] with [$o] in [$workingSource]")
            }
            workingSource = newWorkingSource

            // Replace the matcher with a new one.
            matcher = SubstitutionService.varPattern.matcher(workingSource)
        }

        logger.debug "Converted [$source] to [$workingSource]"

        return workingSource
    }
}