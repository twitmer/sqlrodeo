package com.tom.dbslurper.context

import java.sql.Connection

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.tom.dbslurper.actions.IAction

class DbSlurperContext implements Map<String,Object> {
    
    Logger logger = LoggerFactory.getLogger(DbSlurperContext.class);

    /** Delegate that implements everything. */
    private Map<String,Object> delegate = new HashMap<String,Object>()
    
    /** Actions to implement upon closure. */
    private Deque<IAction> closeActions = new ArrayDeque<IAction>()


    private Connection defaultConnection

    public DbSlurperContext(){
        
        System.setProperty("me", "1")
        delegate.put("sysProps", System.getProperties())
        delegate.put("env", System.getenv())
//        delegate.put("myVar", "1")
        
//        System.getProperties().get
    }

    public DbSlurperContext(DbSlurperContext context){
        delegate.putall(context)
    }

    public int size() {
        return delegate.size();
    }

    public boolean isEmpty() {
        return delegate.isEmpty();
    }

    public boolean containsKey(Object key) {
        return delegate.containsKey(key);
    }

    public boolean containsValue(Object value) {
        return delegate.containsValue(value);
    }

    public Object get(Object key) {
        Object value = delegate.get(key)
        logger.debug "CONTEXT get: $key = $value (${value.getClass().getName()})"
        return value
    }

    public Object put(String key, Object value) {
        logger.debug "CONTEXT put: $key = $value (${value.getClass().getName()})"
        return delegate.put(key, value);
    }

    public Object remove(Object key) {
        return delegate.remove(key);
    }

    public void putAll(Map<? extends String, ? extends Object> m) {
        for(Map.Entry<? extends String, ? extends Object> entry : m.entrySet()){
            put(entry.key, entry.value)
        }
    }

    public void clear() {
        delegate.clear();
    }

    public Set<String> keySet() {
        return delegate.keySet();
    }

    public Collection<Object> values() {
        return delegate.values();
    }

    public Set<java.util.Map.Entry<String, Object>> entrySet() {
        return delegate.entrySet();
    }

    public boolean equals(Object o) {
        return delegate.equals(o);
    }

    public int hashCode() {
        return delegate.hashCode();
    }
    
    /**
     * Close this context.
     */
    public void close(){
        logger.debug "Closing context: ${closeActions.size()} actions."
        while( closeActions.size() > 0)
        {
            IAction closeAction = closeActions.pop()
            logger.debug "Running closeAction: $closeAction"
            closeAction.execute(null,this)
        }
    }
    
    /**
     * Push a close action onto the stack.
     * @param closeAction Action to execute when this context is closed.
     */
    public void pushCloseAction(IAction closeAction){
        closeActions.push(closeAction)
    }
    
    
    /**
     * Find the default connection in the context. This only works if there is only one Connection in the context.
     * @param context
     * @return
     */
    public Connection getDefaultConnection(){
        
        List connections = (List<Connection>)(delegate.values().findAll { it instanceof Connection })
        
        if  (connections.size() == 1){
            return connections.get(0)
        }else {
            throw new RuntimeException("Could not identify default connecton from collection of ${connections.size()} connections")
        }
    }
    
    public String substitute(String source){
        String result = SubstitutionService.substitute(source, this)
        logger.debug "Substitution: Result[$result] from [$source]"
        return result
    }
        
}