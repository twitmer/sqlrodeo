package com.tom.dbslurper

import javax.naming.*

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.xml.sax.Locator

class ActionParser {
    Logger logger = LoggerFactory.getLogger(this.class);

    Node parse(URL resourceUrl){
        logger.info "Parsing content at $resourceUrl"

        // Read in the XML contents.
        def text = resourceUrl.text

        boolean validating = true
        boolean namespaceAware= true
        boolean allowDocTypeDeclaration = true

        // Parse XML into a tree of Nodes
        XmlParser parser = new MyXmlParser(validating,namespaceAware,allowDocTypeDeclaration)
        parser.setErrorHandler(new ParserErrorHandler(resourceUrl))
        parser.setEntityResolver(new SqlRodeoEntityResolver())
        Node root = parser.parseText(text)
        root.attributes().put("resourceUrl",resourceUrl)

        // Walk tree to handle any <include> elements
        walkForInclude(root, resourceUrl)
        return root;
    }

    void walkForInclude(Node node, URL resourceUrl){
        logger.debug "walkForInclude: $node at $resourceUrl"
        // Do nothing for null or String nodes.
        if ( node == null ) {
            return;
        }

        if (node.name().equals("include")){
            URL relativeUrl = resourceUrl.toURI().resolve(".").resolve(node.attribute("href")).toURL()

            // Append these nodes to the include node, with their qualified URL.
            node.append(parse(relativeUrl))
            return;
        }

        // Walk the children.
        List kids = node.children()
        if (kids != null && kids.size() > 0){
            for(Object kid:kids){
                if ( kid instanceof Node ){
                    walkForInclude( kid, resourceUrl )
                }
            }
        }
    }
}