package com.tom.dbslurper

import org.apache.commons.jexl2.Expression
import org.apache.commons.jexl2.JexlContext
import org.apache.commons.jexl2.JexlEngine
import org.apache.commons.jexl2.MapContext
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tom.dbslurper.context.DbSlurperContext

class JexlService {
    
    private static final Logger logger = LoggerFactory.getLogger(JexlService.class);

    private JexlService() {
    }

    public static Object evaluate(String expressionString, DbSlurperContext context){

        // Create engine and context.
        JexlEngine jexl = new JexlEngine();
        JexlContext jc = new MapContext(context);

        // Create and evaluate expression
        Object o = jexl.createExpression( expressionString).evaluate(jc)

        logger.debug "Evaluated $expressionString to $o (${o.getClass().getName()})"
        return o;
    }


    public static boolean evaluateBoolean(String expressionString, DbSlurperContext context){
        Object result = evaluate(expressionString, context)

        if (result instanceof Boolean) {
            return (Boolean)result
        }else{
            throw new RuntimeException("Expected boolean result from $expressionString, but received: ${result.getClass().getName()}")
        }
    }
}
