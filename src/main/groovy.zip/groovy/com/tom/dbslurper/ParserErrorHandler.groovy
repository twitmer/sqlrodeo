package com.tom.dbslurper

import javax.naming.*

import org.slf4j.Logger;import org.slf4j.LoggerFactory;
import org.xml.sax.ErrorHandler
import org.xml.sax.SAXException
import org.xml.sax.SAXParseException

class ParserErrorHandler implements ErrorHandler{
    Logger logger = LoggerFactory.getLogger(this.class);
    
    URL resourceUrl

    ParserErrorHandler(URL resourceUrl){
        this.resourceUrl=resourceUrl
    }


    @Override
    public void warning(SAXParseException exception) throws SAXException {
        logger.debug "WARNING: file=" + resourceUrl + ", " + exception
    }

    @Override
    public void error(SAXParseException exception) throws SAXException {
        throw new UnsupportedOperationException("FATAL: file=" + resourceUrl + ", " + exception, exception)
    }

    @Override
    public void fatalError(SAXParseException exception) throws SAXException {
        throw new UnsupportedOperationException("FATAL: file=" + resourceUrl + ", " + exception, exception)
    }
}
