package com.tom.dbslurper

import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import com.tom.dbslurper.actions.ActionFactory;
import com.tom.dbslurper.actions.IAction
import com.tom.dbslurper.context.DbSlurperContext

class TreeWalker {
    Logger logger = LoggerFactory.getLogger(this.class);
    
    public long count(Node node) {

        logger.debug "node name="+node.name()
        if ( node.name().equals("query")){
            // Short-circuit for query nodes, since they control their own children.
            logger.debug "short-circuit!"
            return 1;
        }

        NodeList kids = node.children();
        long count = 1;
        if (kids != null && kids.size() > 0) {
            for (Object kid: kids){
                if ( kid instanceof Node){
                    //                    logger.debug "Counting kid=(${kid.getClass().getName()})"
                    count += this.count((Node)kid)
                }
            }
        }
        return count;
    }

    public void walk(String indent, Object nodeObj ) {
        if ( nodeObj instanceof String ){
            return;
        }

        Node node = (Node)nodeObj;
        logger.debug indent + "Node ${node.name()}, ${node.attributes()}"
        for (Object child : node.children()) {
            walk(indent + "   ", child)
        }
    }

    public void validate(Object nodeObj ) {
        if ( !(nodeObj instanceof Node)){
            return;
        }

        Node node = (Node)nodeObj;
        logger.debug "Validating Node ${node.name()}, ${node.attributes()}"

        IAction action = new ActionFactory().build(node)
        try {
            action.validate(node)
        } catch (Exception e) {
            throw new RuntimeException("Error while validating: <${node.name()}> element at " + action.resolveResourceUrl(node) + " line " + node.attribute("_line") + ": " + e.getMessage(), e) 
        }

        for (Object child : node.children()) {
            validate(child)
        }
    }

    public void execute(Node node, DbSlurperContext context) {
        // Execute action, returning if the node has no children, or returns a value indicating the children should not be executed.
        if ( !new ActionRunner().execute(node,context) || node.children() == null){
            return
        }

        // Run each child of type 'Node'. (Strings are values, typically consumed by their parent.)
        List kids = node.children()
        for( int i=0; i<kids.size();++i){
            if ( kids.get(i) instanceof Node){
                Node kidNode = (Node)kids.get(i)
                execute(kidNode,context)
            }
        }
    }
}