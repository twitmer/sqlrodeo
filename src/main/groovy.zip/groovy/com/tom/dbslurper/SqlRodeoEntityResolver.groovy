package com.tom.dbslurper

import java.io.IOException;

import org.xml.sax.EntityResolver
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

class SqlRodeoEntityResolver implements EntityResolver {

    private static final String DTD_NAME = "db-slurper.dtd";
    private static final String RES_PATH = "/scriptella/dtd/" + DTD_NAME;

    @Override
    public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {

        println "Resolving entity publicId=$publicId, systemId=$systemId"

        if (systemId != null && systemId.trim().endsWith("db-slurper.dtd")) {
            InputStream stream = this.getClass().getResourceAsStream("/db-slurper.dtd");
            println "Our DTD. Stream found?: " + (stream != null)
            if (stream == null) {
                throw new IllegalStateException("db-slurper.dtd not found on classpath.");
            }
            return new InputSource(stream);
        }
        return null;
    }
}
