package com.tom.dbslurper

import org.slf4j.Logger;import org.slf4j.LoggerFactory
import org.slf4j.Logger;import org.slf4j.LoggerFactory

import com.tom.dbslurper.context.DbSlurperContext

class DbSlurper {
    Logger logger = LoggerFactory.getLogger(this.class);




    Map execute( URL resourceUrl ){
        return execute( resourceUrl, [:])
    }

    Map execute( URL resourceUrl, Map contextSeed ){

        // assume that the first command-line arg
        // contains a file name
        // - on Windows, something like
        //   "C:\home\index.xml"
        // - on Unix, something like
        //   "/usr/home/index.xml"
        String fileName = "db-slurper.dtd"
        File fileObject = new File(fileName);
        URL fileURL = fileObject.toURI().toURL();
        String systemID = fileURL.toExternalForm();
        println "systemId is now $systemID"

        // Validate and parse all XML, generating actions as we go.
        Node root =  new ActionParser().parse(resourceUrl)
        logger.debug "DbSlurper: Done parsing XML resources. Now walking tree."

        TreeWalker tw = new TreeWalker()
        //        tw.walk("", root)
        tw.validate(root)

        //        long count = tw.count(root);
        //        logger.debug "nodecount=$count"

        //        AggregateAction root = new ActionParser().parseRoot(resourceUrl)

        // Populate the context
        // Add all system properties and environmentals, so we can get things like com.probuild.runtime.env.
        DbSlurperContext context = new DbSlurperContext()
        context.putAll(contextSeed);


        try{
            // Execute the action tree.
            logger.debug "******** EXECUTING COMMANDS"
            tw.execute(root,context);
        }
        catch(Exception ex){
            ex.printStackTrace(System.err)
            throw ex;
        }
        finally{
            context.close();
        }
    }
}