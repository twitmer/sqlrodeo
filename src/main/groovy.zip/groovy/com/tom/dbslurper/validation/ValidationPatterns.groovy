package com.tom.dbslurper.validation

import java.util.regex.Pattern

class ValidationPatterns {

    public static Pattern varPattern = ~/\$\{\p{Alpha}\w*\}/

    /** All id elements in the XML files must follow this pattern. */    
    public static final Pattern IDENTIFIER = ~/\p{Alpha}\w*/

    private ValidationPatterns() {
        // TODO Auto-generated constructor stub
    }
}
