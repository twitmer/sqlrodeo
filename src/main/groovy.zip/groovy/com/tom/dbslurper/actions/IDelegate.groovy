package com.tom.dbslurper.actions

import com.tom.dbslurper.context.DbSlurperContext

interface IDelegate {

    public void execute( DbSlurperContext context, String text );
}
