

package com.tom.dbslurper.actions

import org.apache.commons.dbcp2.BasicDataSource
import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import com.tom.dbslurper.context.DbSlurperContext
import com.tom.dbslurper.util.StringUtils


class CloseBasicDatasourceAction extends BaseAction {
    
    Logger logger = LoggerFactory.getLogger(this.class);

    private final String datasourceId;

    public CloseBasicDatasourceAction(Node node) {
        super()
        datasourceId = node.attribute("id")
    }


    @Override
    public void validate(Node node) {
        if (StringUtils.isEmpty(node.attribute("id"))){
            throw new RuntimeException("Generated close-datasource node missing id: ${node.attributes()}")
        }
    }

    @Override
    public void execute(Node node, DbSlurperContext context) {
        // NOTE: Node will be null here.
        logger.debug "CloseBasicDatasourceAction: $datasourceId"
        BasicDataSource ds = (BasicDataSource )context.remove(datasourceId)

        if ( ds == null){
            logger.debug "Datasource not found, doing nothing."
            return;
        }

        if ( !ds.isClosed()){
            logger.debug "Closing datasource $datasourceId"
            ds.close();
        }
    }

    @Override
    public String toString() {
        return "CloseBasicDatasourceAction []";
    }
}