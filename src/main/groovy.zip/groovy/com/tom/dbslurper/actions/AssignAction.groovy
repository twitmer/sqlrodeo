package com.tom.dbslurper.actions

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.tom.dbslurper.JexlService
import com.tom.dbslurper.context.DbSlurperContext

class AssignAction extends BaseAction {

    Logger logger = LoggerFactory.getLogger(this.class);


    public AssignAction( Node node) {
        super()
    }

    @Override
    public void execute(Node node, DbSlurperContext context) {

        String id = node.attribute("id")
        String value = node.attribute("value")

        // There's actually an if-condition. Process it now.
        context.put(id,
                JexlService.evaluate(value, context))
    }

    @Override
    public String toString() {
        return "AssignAction";
    }

    @Override
    public void validate(Node node) {
        // Not much to do here.
    }
}
