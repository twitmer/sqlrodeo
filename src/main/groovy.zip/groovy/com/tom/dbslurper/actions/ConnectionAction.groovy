package com.tom.dbslurper.actions

import groovy.util.Node;

import java.sql.Connection

import javax.sql.DataSource

import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import com.tom.dbslurper.context.DbSlurperContext


class ConnectionAction extends BaseAction {
    
    Logger logger = LoggerFactory.getLogger(this.class);

    public ConnectionAction(Node node) {
        super()
    }

    @Override
    public void execute(Node node, DbSlurperContext context) {

        String  dataSourceId = node.attribute("datasource-id")
        String  id = node.attribute("id")
        boolean autocommit = Boolean.parseBoolean(node.attribute("autocommit"))

        DataSource ds = (DataSource)context.get(dataSourceId)
        if ( ds == null){
            throw new RuntimeException("Datasource not found: " + dataSourceId)
        }

        Connection conn = ds.getConnection();

        // Update autocommit setting, if needed.
        if ( conn.autoCommit != autocommit){
            logger.debug "Switching connection autocommit to $autocommit"
            conn.autoCommit = autocommit
            if ( conn.autoCommit != autocommit){
                throw new RuntimeException("Could not turn autocommit to $autocommit for connection $id")
            }
            logger.debug "connection $id is autocommit?: ${conn.autoCommit}"
        }

        context.put(id, conn);

        // Since we created this connection, we'll take responsibility for closing it.
        logger.debug "Pushing close action"
        context.pushCloseAction(new CloseConnectionAction(node))
    }

    @Override
    public String toString() {
        return "ConnectionAction []";
    }

    @Override
    public void validate(Node node) {
    }
}