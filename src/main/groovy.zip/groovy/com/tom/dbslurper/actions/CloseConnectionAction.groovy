package com.tom.dbslurper.actions

import groovy.util.Node;

import java.sql.Connection

import javax.naming.Context
import javax.naming.InitialContext
import javax.sql.DataSource

import org.apache.commons.dbcp2.BasicDataSource
import org.apache.commons.dbcp2.BasicDataSourceFactory
import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import com.tom.dbslurper.context.DbSlurperContext


class CloseConnectionAction extends BaseAction {
    
    Logger logger = LoggerFactory.getLogger(this.class);

    private final String connectionId;

    public CloseConnectionAction(Node node) {
        super()
        connectionId = node.attribute("id")
    }

    @Override
    public void execute(Node node, DbSlurperContext context) {
        // NOTE: Node will be null here.
        logger.debug "CloseConnectionAction: $connectionId"
        Connection connection = (Connection )context.remove(connectionId)

        if ( connection == null){
            logger.debug "Connection not found, doing nothing."
            return;
        }

        // If connection isn't autocommit, rollback.
        if ( !connection.autoCommit ){
            try {
                logger.debug "Rolling back non-autocommit connection $connectionId"
                connection.rollback();
            } catch (Exception e) {
                logger.debug "Ignore error with rollback: ${e.message}"
            }
        }

        if ( !connection.isClosed()){
            logger.debug "Closing Connection $connectionId"
            try {
                connection.close();
            } catch (Exception e) {
                logger.debug "Ignore error with close: ${e.message}"
            }
        }
    }

    @Override
    public String toString() {
        return "CloseConnectionAction []";
    }

    @Override
    public void validate(Node node) {
        // Nothing to do here; DTD requires 'id' be defined.
    }
}