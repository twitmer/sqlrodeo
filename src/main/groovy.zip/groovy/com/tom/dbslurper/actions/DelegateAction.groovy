package com.tom.dbslurper.actions

import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import groovy.util.Node;

import com.tom.dbslurper.context.DbSlurperContext
import com.tom.dbslurper.util.StringUtils

class DelegateAction extends BaseAction {

    Logger logger = LoggerFactory.getLogger(this.class);

    private final String nodeText

    private final String id

    private final String delegateClass

    public DelegateAction(Node node) {
        super()
        this.nodeText = node.value()
        id = node.attribute("id")
        delegateClass = node.attribute("delegate-class")
    }

    @Override
    public void execute(Node node,DbSlurperContext context) {

        IDelegate delegate

        // First try to find an existing instance of the delegate in the context.
        if ( !StringUtils.isEmpty(id)){
            delegate = (IDelegate)context.get(id)
        }

        // If the delegate wasn't found in the context, we'll need to create it.
        if ( delegate == null && !StringUtils.isEmpty(delegateClass) ){


            println "Using thread context classloader"
            delegate = (IDelegate)Class.forName(delegateClass, true, Thread.currentThread().getContextClassLoader()
                    ).newInstance();

            //            delegate = (IDelegate)Class.forName(delegateClass).newInstance()

            // Delegate created. If an 'id' is specified, publish to context to allow for future use.
            if ( !StringUtils.isEmpty(id)){
                context.put(id, delegate)
            }
        }

        // Out of strategies. No idea how to create your delegate!
        if ( delegate == null){
            throw new RuntimeException("Could not find or create delegate: " + node)
        }

        delegate.execute(context, nodeText)
    }

    @Override
    public String toString() {
        return "DelegateAction [" + (node != null ? "node=" + node + ", " : "")
        + (nodeText != null ? "nodeText=" + nodeText + ", " : "") + (id != null ? "id=" + id + ", " : "")
        + (delegateClass != null ? "delegateClass=" + delegateClass : "") + "]";
    }

    @Override
    public void validate(Node node) {
        String id = node.attribute("id")
        String delegateClass = node.attribute("delegate-class")

        if ( StringUtils.isEmpty(id) && StringUtils.isEmpty(delegateClass)){
            throw new RuntimeException("At least one of 'id' or 'delegate-class' is required: $node")
        }
    }
}