package com.tom.dbslurper.actions

import javax.naming.Context
import javax.naming.InitialContext
import javax.sql.DataSource

import org.apache.commons.dbcp2.BasicDataSource
import org.apache.commons.dbcp2.BasicDataSourceFactory
import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import com.tom.dbslurper.context.DbSlurperContext
import com.tom.dbslurper.util.StringUtils
import com.tom.dbslurper.validation.ValidationPatterns


class BasicDatasourceAction extends BaseAction {
    
    private static final Logger logger = LoggerFactory.getLogger(this.class);

    public BasicDatasourceAction(Node node) {
        super()
    }

    @Override
    public void execute(Node node, DbSlurperContext context) {
        String id = node.attribute("id")

        DataSource dataSource = null

        String jndiName = node.attribute("name")
        if ( !StringUtils.isEmpty(jndiName)) {
            try {
                dataSource = buildJndiConnection(jndiName)
                logger.debug "Datasource $jndiName resolved."
            } catch (Exception e) {
                logger.debug "Datasource $jndiName failed to resolve: " + e.getMessage()
            }
        }

        if ( dataSource == null){
            dataSource = buildBasicDatasource(node);

            // Since we created this datasource, we'll take responsibility for closing it.
            context.pushCloseAction(new CloseBasicDatasourceAction(node))
        }

        if ( dataSource == null){
            throw new UnsupportedOperationException("Cannot create datasource from: " + node)
        }

        context.put(id,dataSource);
    }

    private static DataSource buildJndiConnection(String jndiName){
        Context initCtx = new InitialContext()
        Object jndiObject =initCtx.lookup("java:comp/env/" + jndiName)

        if ( jndiObject != null && jndiObject instanceof DataSource ){
            return (DataSource)jndiObject;
        }else{
            throw new UnsupportedOperationException("Cannot create connection with jndiName=" + jndiName
            + ", jndiObject=" + jndiObject
            + ", class=" + jndiObject?.getClass()?.getName())
        }
    }

    private static  DataSource buildBasicDatasource(Node node){
        Properties props = new Properties();
        node.attributes().each { entry ->
            props.put(entry.key, entry.value)
        }

        BasicDataSource bds = BasicDataSourceFactory.createDataSource(props);
        logger.debug "DataSource: $bds"
        return bds;
    }

    @Override
    public String toString() {
        return "BasicDatasourceAction []";
    }

    @Override
    public void validate(Node node) {
        if ( !ValidationPatterns.IDENTIFIER.matcher(node.attribute("id")).matches()){
            throw new IllegalArgumentException("Invalid id: "+node.attribute("id"))
        }
    }
}