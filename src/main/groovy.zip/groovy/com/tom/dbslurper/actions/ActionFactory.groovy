package com.tom.dbslurper.actions

import org.slf4j.Logger;import org.slf4j.LoggerFactory;


class ActionFactory {
    
    Logger logger = LoggerFactory.getLogger(this.class);
    
    public IAction build(Node node){
        Node parent = null;
        switch(node.name()){
            case "datasource": return new BasicDatasourceAction(node)
            case "connection": return new ConnectionAction(node)
            case "commit": return new CommitAction(node)
            case "rollback": return new RollbackAction(node)
            case "query": return new QueryAction(node)
            case "delegate": return new DelegateAction(node)
            case "sql": return new SqlAction( node)
            case "assign": return new AssignAction( node)
            
            case "aggregate":
            case "db-slurper":
            case "include":
                return new AggregateAction(node)

            default:
                throw new UnsupportedOperationException("Unrecognized node: ${node.name()} (${node.attributes()})")
        }
    }
}