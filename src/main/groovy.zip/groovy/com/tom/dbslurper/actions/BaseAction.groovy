package com.tom.dbslurper.actions

import java.sql.Connection

import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import com.tom.dbslurper.context.DbSlurperContext
import com.tom.dbslurper.util.StringUtils

public abstract class BaseAction implements IAction {
    
    Logger logger = LoggerFactory.getLogger(this.class);

    public Connection getConnection(Node node, DbSlurperContext context) {

        Node workingNode = node;
        while (workingNode != null && StringUtils.isEmpty(workingNode.attribute("connection-id"))) {

            String connId = workingNode .attribute("connection-id")
            if (!StringUtils.isEmpty(connId)) {

                Connection conn = context.get(connId);
                if (conn == null) {
                    throw new RuntimeException("Connection not found: " + connId)
                }
                return conn
            }

            workingNode = workingNode.parent()
        }

        // Didn't find connection-id on parent node, so see if the context knows which it is.
        return context.getDefaultConnection()
    }

    public URL resolveResourceUrl(Node node) {

        URL resourceUrl = node.attribute("resourceUrl")
        if ( null != resourceUrl){
            return resourceUrl
        }

        Node workingNode = node;
        while (workingNode != null && resourceUrl == null) {

            resourceUrl = workingNode .attribute("resourceUrl")
            if ( null != resourceUrl){
                return resourceUrl
            }

            workingNode = workingNode.parent()
        }

        // Didn't find connection-id on parent node, so see if the context knows which it is.
        throw new RuntimeException("Could not determine resourceUrl!")
    }

    public URL resolveRelativeUrl(Node node, String href){
        URL resourceUrl = resolveResourceUrl(node)
        return resourceUrl.toURI().resolve(".").resolve(href).toURL()
    }

    @Override
    public String toString() {
        return "BaseAction []";
    }
}
