package com.tom.dbslurper.actions

import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import groovy.util.Node;

import com.tom.dbslurper.context.DbSlurperContext

class AggregateAction extends BaseAction {

    Logger logger = LoggerFactory.getLogger(this.class);
    private final Node node

    URL resourceUrl

    public AggregateAction( Node node) {
        super()
        this.node = node
        this.resourceUrl = node.attribute("resourceUrl")
    }

    @Override
    public void execute(Node node, DbSlurperContext context) {
        String resourceUrl = this.resolveResourceUrl(node);
        if ( null == resourceUrl){
            resourceUrl = this.resolveResourceUrl(node);
            throw new RuntimeException("resourceUrl should not be null!");
        }
        logger.debug "** Running doc at ${resolveResourceUrl(node)} with ${node.children()?.size()} actions."
    }

    @Override
    public String toString() {
        return "AggregateAction [ resourceUrl=" + resourceUrl  +
        (node != null ? ", node=" + node + "" : "") + "]";
    }

    @Override
    public void validate(Node node) {
        // Not much to do here.
    }
}
