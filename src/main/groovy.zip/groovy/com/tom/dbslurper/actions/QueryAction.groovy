package com.tom.dbslurper.actions

import java.sql.Connection
import java.sql.ResultSet
import java.sql.ResultSetMetaData
import java.sql.Statement

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.tom.dbslurper.TreeWalker
import com.tom.dbslurper.context.DbSlurperContext
import com.tom.dbslurper.util.StringUtils

class QueryAction extends BaseAction {

    Logger logger = LoggerFactory.getLogger(this.class);

    public QueryAction(Node node) {
        super()
    }

    @Override
    public void execute(Node node,DbSlurperContext context) {

        String queryString = node.children().get(0)
        String[] publishAs = getPublishAs(node.attribute("publish-as"))
        boolean substitute = Boolean.parseBoolean(node.attribute("substitute"))
        String rowNumId = node.attribute("rownum")

        List queryChildren = new ArrayList(node.children())
        queryChildren.remove(0)

        //  Variable substitution (i.e. '${release}' -> '1')
        if  ( substitute){
            queryString = context.substitute(queryString)
            //            logger.debug "Query after substitution: $queryString"
        }

        Connection connection = getConnection(node,context)
        Statement stmt = connection.createStatement()
        logger.info "Executing statement [$queryString]"

        long resultCount = 0;
        long rowCount = 0;
        try{
            ResultSet result = stmt.executeQuery(queryString)
            ResultSetMetaData md = result.metaData
            try{
                while(result.next()){
                    publishRow(queryChildren, result, context, publishAs)
                    if (!StringUtils.isEmpty(rowNumId)){
                        context.put(rowNumId,rowCount)
                    }
                    ++resultCount;
                }

            }
            finally{
                try {
                    result.close()
                } catch (Exception e) {
                    logger.debug("Ignoring error closing resultSet: " + e.message)
                }
            }
        }
        finally{
            try {
                stmt.close()
            } catch (Exception e) {
                logger.debug("Ignoring error closing statement: " + e.message)
            }
        }

        // TODO: "result.rowCount", "result.rowNum", "result.row[colName]", etc.
        String rowCountId = node.attribute("rowcount")
        if (!StringUtils.isEmpty(rowCountId)){
            context.put(rowCountId,resultCount)
        }
    }

    ResultSet executeQuery(Connection connection, String sqlText){
        Statement stmt = connection.createStatement()
        logger.info "Executing statement [$sqlText]"

        ResultSet result = stmt.executeQuery(sqlText)
        try {
            stmt.close()
        } catch (Exception e) {
            //            logger.debug "Ignoring problem closing statement: ${e.message}"
        }
    }

    String[] getPublishAs(String publishAs){

        if (StringUtils.isEmpty(publishAs)){
            return new String [0]
        }

        String [] result = publishAs.split(",")
        for( int i=0; i<result.length; ++i){
            result[i] = result[i].trim()
        }

        return result
    }

    void publishRow(List queryChildren, ResultSet rs, DbSlurperContext context, String[] publishAs){

        // Publish each column of this result row to the context.
        ResultSetMetaData md = rs.metaData
        int colCount = md.getColumnCount()

        // TODO: Consider alternative of publishing row as a Map that must be queried instead, e.g. jexl="row[id] == 'Alan'"
        for(int i=1; i<=colCount; ++i){
            if ( publishAs.length >= i){
                context.put(publishAs[i-1], rs.getObject(i))
            }
        }

        if ( queryChildren.size() > 0){
            TreeWalker walker = new TreeWalker()
            for(int i=1; i<=queryChildren.size(); ++i){
                logger.debug "Running query child $i: " +queryChildren.get(i)
                walker.execute(queryChildren.get(i), context)
            }
        }

        logger.debug "Done Running ${queryChildren.size()} child actions"
    }

    @Override
    public String toString() {
        return "QueryAction []";
    }

    @Override
    public void validate(Node node) {
        String condition = node.attribute("if")
        String connectionId = node.attribute("connection-id")

        List children = node.children()

        if (children.size() < 1){
            throw new UnsupportedOperationException("Query element missing query text.")
        }

        if (!(children.get(0) instanceof String)){
            String msg= "First child of <query> must be the query text,  not: ${children.get(0).getClass().getName()}"
            throw new UnsupportedOperationException(msg)
        }

        // Verify all subsequent entries are Nodes
        for(int i=1;i<children.size();++i){
            Object kid = children.get(i)
            if (!( kid instanceof Node)){
                String msg = "Query node (${node.attributes()}) may not contain Strings after the first element. Invalid value: $kid"
                throw new UnsupportedOperationException(msg)
            }
        }

    }
}