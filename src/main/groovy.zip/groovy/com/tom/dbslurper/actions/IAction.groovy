package com.tom.dbslurper.actions

import groovy.util.Node;

import java.net.URL;
import java.sql.Connection

import com.tom.dbslurper.context.DbSlurperContext

interface IAction {

    public void execute( Node node, DbSlurperContext context )

    public Connection getConnection(Node node, DbSlurperContext context)

    /**
     * Evaluate whether the given node contains valid attributes and values for the intended action.
     * @param node
     */
    public void validate(Node node)

    public URL resolveResourceUrl(Node node)
}
