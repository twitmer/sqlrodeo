package com.tom.dbslurper.actions

import java.sql.Connection
import java.sql.Statement

import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import com.tom.dbslurper.TreeWalker
import com.tom.dbslurper.context.DbSlurperContext
import com.tom.dbslurper.util.StringUtils

class SqlAction extends BaseAction {
    
    Logger logger = LoggerFactory.getLogger(this.class);

    public SqlAction( Node node) {
        super()
//        List children = node.children()
//        for( Object child: children){
//            logger.debug "\t sqlaction child: $child"
//        }
    }

    @Override
    public void execute(Node node, DbSlurperContext context) {

        logger.info "SqlAction: $node with ${node.children()?.size()} children"

        String href = node.attribute("href");
        boolean oneStatement = Boolean.parseBoolean( node.attribute("oneStatement") )
        NodeList children = node.children()

        TreeWalker tw = new TreeWalker()
        Connection connection = this.getConnection(node, context)


        // Case 1: 1 child, consisting of a string
        // Case 2: No child, has an href
        // Case 3: Multi-children, all Nodes
        // Case 4: Multi-children, mix of Nodes and Strings (inline sql)

        // Check for Case 1
        if ( StringUtils.isEmpty(href) ){
            if ( children == null){
                throw new RuntimeException("Failed case 1: null children")
            }
            if ( children.size() == 1 && children.get(0) instanceof String) {
                String sqlText = children.get(0);
                logger.info "Case 1: Single string child: $sqlText"
                invokeSqlTextLines(connection,sqlText,context)
            }else{
                // Multiple children, possible mix of Nodes and Strings
                for( int i=0; i<children.size(); ++i){
                    if ( children.get(i) instanceof String ){
                        // Inline Sql
                        String sqlText = (String)children.get(0);
                        logger.info "Case 3: Child is string: $sqlText"
                        invokeSqlTextLines(connection,sqlText,context)
                    }else{
                        Node childNode = (Node)children.get(i)
                        logger.info "Case 3: Child is node: ${childNode.name()} (${childNode.attributes()})"
                        tw.execute(childNode, context)
                    }
                }
            }
        }

        // Check for Case 2
        else { // href is not empty!
            URL sqlUrl = this.resolveRelativeUrl(node, href);
            String sqlText = sqlUrl.text
            logger.info "Case 2, sqlUrl=$sqlUrl, sqlText=$sqlText"
            if ( oneStatement){
                invokeSqlTextAsOneStatement(connection,sqlText,context)
            }else{
                invokeSqlTextLines(connection,sqlText,context)
            }
        }
    }

    void invokeSqlTextLines(Connection connection, String sqlText, DbSlurperContext context){
//        logger.debug "invokeSqlTextLines()"
        String[] stmts = sqlText.trim().split(";")
//        logger.debug "Stmt count: ${stmts.length}"
        for( int i=0; i<stmts.length;++i){
//            logger.debug "Stmt = ${stmts[i]}"
            String stmt = stmts[i].trim()

            if( StringUtils.isEmpty(stmt.trim())){
//                logger.debug "Skipping empty statement"
                continue
            }

//            logger.debug "Executing SQL: $stmt"
            long resultCount = 0;
            executeStatement(connection, stmt)
        }
    }

    void invokeSqlTextAsOneStatement(Connection connection, String sqlText, DbSlurperContext context){
//        logger.debug "invokeSqlTextAsOneStatement()"
//        logger.debug "sqlText = ${sqlText}"
//        logger.debug "Executing SQL: $sqlText"
        long resultCount = 0;
        executeStatement(connection, sqlText)
    }

    void executeStatement(Connection connection, String sqlText){
        Statement stmt = connection.createStatement()
        logger.info "Executing statement [$sqlText]"
        Boolean resultSetReturned = stmt.execute(sqlText)
        try {
            stmt.close()
        } catch (Exception e) {
            logger.debug "Ignoring problem closing statement: ${e.message}"
        }
    }

    @Override
    public String toString() {
        return "SqlAction []";
    }

    @Override
    public void validate(Node node) {
        boolean oneStatement = Boolean.parseBoolean( node.attribute("oneStatement"))
        String href = node.attribute("href")

        // TODO: If href or oneStatement is used, no Node children are allowed.
        if ( !StringUtils.isEmpty(href) || oneStatement){
            logger.debug "sql node has href or onestatement, so no kids allowed."
            List kids = node.children()
            for(Object kid:kids){
                logger.debug "sql kid: ${kid.getClass().getName()}"
            }
        }

        // TODO: Verify other cases...
    }
}
