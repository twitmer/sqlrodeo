package com.tom.dbslurper.actions

import groovy.util.Node;

import java.sql.Connection

import org.slf4j.Logger;import org.slf4j.LoggerFactory;

import com.tom.dbslurper.context.DbSlurperContext


class RollbackAction extends BaseAction {
    
    Logger logger = LoggerFactory.getLogger(this.class);

    public RollbackAction(Node node) {
        super()
    }

    @Override
    public void execute(Node node, DbSlurperContext context) {
        String connectionId = node.attribute("connection-id")
        Connection conn = (Connection)context.get(connectionId)
        if ( conn == null){
            throw new RuntimeException("Connection not found: " + connectionId)
        }

        conn.rollback();
    }

    @Override
    public String toString() {
        return "RollbackAction []";
    }

    @Override
    public void validate(Node node) {
        // Nothing to do here.
    }
}